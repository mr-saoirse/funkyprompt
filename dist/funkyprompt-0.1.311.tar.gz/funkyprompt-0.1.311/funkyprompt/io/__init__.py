"""
we may add some clients in here for pulsar and the like but we may push that out to monologue instead
"""
