"""

we have function signatures for testing stuff
we also have really functions that connect to data stores (run the scripts to populate the data)
"""
